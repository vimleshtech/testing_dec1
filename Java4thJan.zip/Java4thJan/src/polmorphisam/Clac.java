package polmorphisam;

public class Clac {

	void add(int a, int b)
	{
		int m =a+b;
		System.out.println(m);
		
	}
	void add(int a, int b,int c)
	{
		int x =a+b+c;
		System.out.println(x);
		
	}
	void add(double a, int b)
	{
		double c =a+b;
		System.out.println(c);
	}
	
}
