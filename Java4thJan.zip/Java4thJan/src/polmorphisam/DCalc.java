package polmorphisam;

public class DCalc extends Clac {

	void mul(int a, int b)
	{
		System.out.println(a*b);
	}
	void add(int a, int b)
	{
		System.out.println("sum of two numbers : "+(a+b));
	}
}

