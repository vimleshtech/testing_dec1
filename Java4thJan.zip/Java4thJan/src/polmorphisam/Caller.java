package polmorphisam;

public class Caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DCalc o =new DCalc();
		o.add(11.2, 3);
		o.add(11, 3); //override
		o.add(11, 33,33);
		o.mul(11, 3);
		
		Clac o1 =new Clac();
		o1.add(1, 11);
		
		//overriding
		Clac dd =new DCalc();
		dd.add(11, 3);
		
		
	}

}
