package example;

public class Employee {

	private String uname;
	private int s1,s2,s3;
	
	protected String name;//can be called from child class but not outside
	
	final int cess=5;
	
	static int a;
	int b;
	
	public Employee()
	{
		System.out.println("object is created");
		///cess =10;
		
	}
	public	Employee(String country)
	{
		if(country.equals("india"))
		{
			uname="Guest User";
			s1=300000;
			s2=500000;
			s3=1000000;
		}
		else if(country.equals("us"))
		{
			uname="New User";
			s1=1000000;
			s2=5000000;
			s3=10000000;
		}
		else
		{
			uname="New User";
		}
	}
	
	public Employee(Employee o)
	{
		uname = o.uname;
		s1=o.s1;
		s2=o.s2;
		s3=o.s3;
	}
	
	public static void test()
	{
		System.out.println("static function");
	}
	public void tax(int sal)// if function is private then can be called within this class itself and not from anywhere else
	
	{
		if(sal<s1)
		{
			System.out.println(0);
		}
		else if(sal<s2)
		{
			System.out.println( (sal-s1)*.10);
		}
		else if(sal<s3)
		{
			System.out.println( s1*.10+  (sal-s2)*.20);
		}
		else
		{
			System.out.println( s1*.10+ s2*.20+ (sal-s3)*.30);
		}
	}
}
