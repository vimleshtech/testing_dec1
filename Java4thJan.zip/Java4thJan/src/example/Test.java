package example;

public class Test extends Extended {

}


class test2{
	
	
}