package example;

public class Extended extends Employee {
	
	String name;
	int age;
	
	void input(String name, int age)
	{
		this.name =name;
		this.age = age;// this is for current class object
		super.name =name;//global class data member
		
		
	}
	void show()
	{
		System.out.println(name);
		System.out.println(age);
	}
}
