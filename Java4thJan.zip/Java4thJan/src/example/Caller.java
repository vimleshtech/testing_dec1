package example;

public class Caller {

	void add()
	{
		System.out.println();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Caller cc =new Caller();
		cc.add();
		//cannot be invoke because main is statac function and object is created to invoke the main function
		//this.add()
		
		
		Employee o =new Employee();
		Employee o2 =new Employee();
		o.tax(333444);
		
		//access static 
		Employee.a=11;
		Employee.test();
		
		o.a =11;
		o.test();
		
		//cannot access
		//Employee.b=11;
		//Employee.tax(111);
		
		
		//
		o.a =11;
		o2.a =33;
		
		o.b =11;
		o2.b =33;
		
		System.out.println(o.a);//33 
		System.out.println(o2.a);//33
		
		System.out.println(o.b);//11
		System.out.println(o2.b);//33
		
		
		Employee o1 =new Employee("us");
		o1.tax(333444);
		
		
		Employee oo = new Employee(o);
		oo.tax(333444);
		
		
		///
		Extended e =new Extended();
		e.input("raman", 29);
		e.show();
		e.tax(33334);
		
		
	}

}
