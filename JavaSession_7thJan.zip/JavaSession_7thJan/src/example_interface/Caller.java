package example_interface;

public class Caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Extended e =new Extended(); //can access Ia,and Ib interface methods 
		e.add(11, 1);
		int s = e.sub(11, 2);
		System.out.println(s);
		
		Ia a =new Extended(); //can be access Ia's methods only 
		a.add(11, 32); 
		
		
		Ib b =new Extended(); //can be access Ib's methods only 
		s = b.sub(11, 32);
		System.out.println(s);
		
		
	}

}
