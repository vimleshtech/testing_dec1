package example_interface;

public class Extended implements Ia,Ib {

	@Override
	public int sub(int a, int b) {
		// TODO Auto-generated method stub
		return a-b;
	}

	@Override
	public void add(int a, int b) {
		// TODO Auto-generated method stub
		
		System.out.println(a+b);
		
	}

}
