package example_interface;

public interface Ib {
	int sub(int a, int b);
	
}
