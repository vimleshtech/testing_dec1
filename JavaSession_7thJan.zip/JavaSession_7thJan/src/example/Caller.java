package example;

public class Caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Common c =new Common();
		
		Common c =new Extended();
		//or 
		Extended c1 =new Extended();
		c1.add(11, 232);
		c1.tax(11111);
		
		
		
	}

}
