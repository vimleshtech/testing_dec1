package example;

public abstract class Common {
	
	void add(int a, int b)
	{
		System.out.println(a+b);
	}
	abstract void  tax(int sal);
	
}
