package example;

public class Extended extends Common {

	@Override //annotation 
	void tax(int sal) {
	
		if(sal<300000)
			System.out.println("non taxable");
		else
			System.out.println("taxable");
		
	}

}
