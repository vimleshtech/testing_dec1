package example;

import java.util.Scanner;

public class Questions {

	public static void main(String[] args) {

		//wap to get count of space from sentence
		Scanner sc =new Scanner(System.in);
		String name;
		
		System.out.println("ener string : ");
		name = sc.nextLine(); //sc.nextLine();
		
		System.out.println(name.length() - name.replace(" ","").length() );
		

	}

}
