package example;

import java.util.Scanner;

public class ExceptionExample {

	public static void main(String[] args) {

		int n,d,o;
		Scanner sc =new Scanner(System.in);
		
		System.out.println("enter data : ");
		n = sc.nextInt();
		
		System.out.println("enter data : ");
		d = sc.nextInt();
		
		try
		{
			//div  //ATM 
			if(d<0)
			{
				ArithmeticException ex =new ArithmeticException("divisor canot be less than 0");
				throw ex;
			}
			o = n/d;
			System.out.println(o);			
		 
		}
		catch (ArithmeticException e) {
			System.out.println(e);
		}
		catch (ArrayIndexOutOfBoundsException e) {
			
		}
		catch (Exception er)  //Exception is generic class which can receive any type of error 
		{
			System.out.println("Data is not correct, pls again!!! ");
			 
		}
		finally
		{
			//logout
		}
		
		//add
		o =n+d;
		System.out.println(o);
		
		
		
		

	}

}
