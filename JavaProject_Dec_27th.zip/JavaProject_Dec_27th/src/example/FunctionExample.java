package example;

import java.util.Scanner;

public class FunctionExample {

	public static void main(String[] args) {
		//invoke to function 
		welcome();
		
		//
		int a,b;
		a =getdata();
		b = getdata();
		System.out.println(a+b);
		
		//or 
		System.out.println(getdata()+getdata());
		
		//
		add(11,22);
		
		//
		int o  = sub(getdata(),getdata());
		System.out.println(o);
	}

	//no argument no return 
	static void welcome()
	{
		System.out.println("This class contains following functions \n 1. welcome \n 2. getdata \n 3. add \n 4. sub ");
	}
	//no argument with return 
	static int getdata()
	{
		int n;
		Scanner s =new Scanner(System.in);
		System.out.println("eter data : ");
		n = s.nextInt();
		return n;		
		
	}
	
	//argument with no return 
	static void add(int a, int b)
	{
		System.out.println(a+b);
	}

	//argument with return
	static int sub(int a, int b)
	{
		return a-b;
		
	}
	
}
