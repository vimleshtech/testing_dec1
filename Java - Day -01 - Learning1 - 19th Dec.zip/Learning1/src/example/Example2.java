package example;

public class Example2 {

	public static void main(String[] args) {

		byte b =100;
		System.out.println(b);
		
		
		short s =1003;
		System.out.println(s);
		
		
		int i =100333333;
		System.out.println(i);
		
		long l =10033333343333333l;
		System.out.println(l);
		
		float f =1003333334333.3333f;
		System.out.println(f);
		
		
		double d =1003333334333.3333444456555d;
		System.out.println(d);
		
		
		boolean bo =true;
		System.out.println(bo);
		

		char c ='d';
		System.out.println(c);
		

		String ss ="shjsgshsfh sfgss gfsssss";
		System.out.println(ss);
		
	

	}

}
