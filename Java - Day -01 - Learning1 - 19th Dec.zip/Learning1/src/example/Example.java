package example;

public class Example 
{
	//global variable 
	int a;			//instance variable		
	static int b;   //static variable 
		
	
	public static void main(String[] v) 
	{		
		System.out.println("Hi, this is my first code..");
		
		//declare variable 
		int a,b,c;		
		a =33;
		b=55;		
		c=a+b;		
		System.out.println(c);
		
	}
	
	public static void add()
	{
			Example o =new Example();
			o.a =11;
			
			b=33;
			//c=00;
			
	}
}
