package example;


public class Example3 {

	public static void main(String[] args) {

		int a,b,c;
		a=44;
		b =55;
		c=440;
		
		//show greater no
		if(a>b)
		{
			System.out.println("a si gt");
		}
		else
		{
			System.out.println("b is gt");
		}
		
		//
		if(a>b && a>c)
		{
			System.out.println("a is gt");	
		}
		else if(b>a && b>c)
		{
			System.out.println("b is gt");
		}
		else
		{
			System.out.println("c is gt");
		}
		
	}

}
