package example;
import java.util.List;
//import java.awt.List;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.apache.commons.*;

public class Automation1 {

	public static void main(String[] args) throws IOException {
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.yahoo.com");
		
		
		String t = driver.getTitle();
		System.out.println(t);
		
		String u = driver.getCurrentUrl();
		System.out.println(u);
		
		
		String s = driver.getPageSource();
		//System.out.println(s);
		
		
		//driver.close();//close current window 
		//driver.quit(); //close current and associated instance
		
		//screen shot
		/*
		File src=	((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		System.out.println(src);
		FileWriter f =new FileWriter("C:\\Users\\welcome\\Downloads\\software testing\\chromedriver_win32\\out.png");		
		BufferedWriter b =new BufferedWriter(f);
		b.write(src.toString());
		*/


		List<WebElement> el = 	driver.findElements(By.tagName("a"));
		
			
		System.out.println(el.size());
		for(WebElement e : el)
			System.out.println(e.getText());
		
	}

}
