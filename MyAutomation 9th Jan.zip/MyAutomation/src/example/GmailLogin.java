package example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GmailLogin {

	public static void main(String[] args) {

		WebDriver driver =new ChromeDriver();
		driver.get("https://www.google.com/");

		driver.findElement(By.linkText("Gmail")).click();
		driver.findElement(By.xpath("/html/body/nav/div/a[2]")).click();
		
		
		driver.findElement(By.id("identifierId")).sendKeys("vimlesh073@gmail.com");
		
		driver.findElement(By.id("identifierNext")).click();
		
		/*
		 * By.id()
		 * By.name()
		 * By.linkText()
		 * By.partialLinkText()
		 * By.xpath()
		 * By.className()
		 * By.cssSelector()
		 * By.tagName()
		 * etc.
		 */
	}

}
